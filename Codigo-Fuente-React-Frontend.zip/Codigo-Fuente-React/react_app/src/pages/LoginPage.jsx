import Login from "../components/Login.jsx";


const LoginPage = () => {
    return(
        <>
        <Login></Login>
        </>
    );
}


export default LoginPage;