import TableProductos from "../components/TableProductos.jsx";


const HomePage = () => {
    
    return(
        <>
       <div className="home-container">
         <TableProductos></TableProductos>
       </div>
        </>
    );
}


export default HomePage;