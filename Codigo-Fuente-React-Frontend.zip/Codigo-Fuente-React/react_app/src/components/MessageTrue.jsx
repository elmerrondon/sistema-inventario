



const MessageTrue = ({msg}) => {

    return(
        <div className="true-container">
            <p>{msg}</p>
        </div>
    );
};


export default MessageTrue;