

const MessageError = ({msg}) => {

    return(
        <div className="error-container">
            <p>{msg}</p>
        </div>
    );
};


export default MessageError;